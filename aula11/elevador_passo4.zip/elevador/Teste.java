package com.senac.elevador;

public class Teste {

	public static void main(String[] args) {
		new Janela();
	}

}
