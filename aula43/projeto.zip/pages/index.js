// pages/index.js
import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs } from 'firebase/firestore';

export default function Home() {
    const [name, setName] = useState('');
    const [usuarios, setUsuarios] = useState([]);

    // Função para buscar os usuários
    const fetchUsuarios = async () => {
        try {
            const querySnapshot = await getDocs(collection(db, 'usuarios'));
            const usersList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            setUsuarios(usersList);
        } catch (error) {
            console.error('Erro ao buscar usuários:', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (name.trim() === '') {
            alert('Por favor, insira um nome.');
            return;
        }

        try {
            await addDoc(collection(db, 'usuarios'), { name }); 
            alert('Nome registrado com sucesso!');
            setName('');
            fetchUsuarios(); // Atualiza a lista após adicionar
        } catch (error) {
            console.error('Erro ao registrar nome:', error);
            alert('Erro ao registrar nome. Confira o console para mais detalhes.');
        }
    };

    useEffect(() => {
        fetchUsuarios(); // Busca os usuários quando o componente é montado
    }, []);

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }} >
            <h1>Bem-vindo!</h1>
            <form onSubmit={handleSubmit} style={{ marginBottom: '40px' }} >
                <input 
                    type="text" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    placeholder="Digite seu nome"
                    style={{ padding: '10px', border: '1px solid #ccc', borderRadius: '4px', width: '200px', marginRight: '10px' }}
                />
                <button type="submit" style={{ padding: '10px 15px', backgroundColor: '#4CAF50', color: 'white', border: 'none', borderRadius: '4px' }} >Registrar</button>
            </form>
            <h2>Usuários Cadastrados:</h2>
            <ul style={{ listStyleType: 'none', padding: '0' }} >
                {usuarios.map((usuario) => (
                    <li key={usuario.id} style={{ padding: '5px', borderBottom: '1px solid #aaa' }} >{usuario.name}</li>
                ))}
            </ul>
        </div>
    );
}
