/**  VISOR  */
const visor = document.getElementById('visor');

/** CONSTANTES DOS NÚMEROS */
const bnt0 = document.getElementById('btn0');
const bnt1 = document.getElementById('btn1');
const bnt2 = document.getElementById('btn2');
const bnt3 = document.getElementById('btn3');
const bnt4 = document.getElementById('btn4');
const bnt5 = document.getElementById('btn5');
const bnt6 = document.getElementById('btn6');
const bnt7 = document.getElementById('btn7');
const bnt8 = document.getElementById('btn8');
const bnt9 = document.getElementById('btn9');
const bntPonto = document.getElementById('btnPonto');
const bntDividir = document.getElementById('btnDividir');
const bntSubtrair = document.getElementById('btnSubtrair');
const bntSomar = document.getElementById('btnSomar');
const bntMultiplicar = document.getElementById('btnMultiplicar');
const bntLimpar = document.getElementById('btnLimpar');
const bntResultado = document.getElementById('btnResultado');

/** FUNÇÃO PARA VERIFICAR SE O ÚLTIMO CARACTER DO VISOR É UM OPERADOR */
const operadores = ['+', '-', '*', '/'];   // ARRAY DE OPERADORES
function verificaUltimoCaracter() {
    return operadores.includes(visor.value.slice(-1));
}

/** EVENTO CLICK PARA O TECLADO DA CALCULADORA*/
bnt0.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '0';
    } else {
        visor.value += '0';
    }
});

bnt1.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '1';
    } else {
        visor.value += '1';
    }
});

bnt2.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '2';
    } else {
        visor.value += '2';
    }
});

bnt3.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '3';
    } else {
        visor.value += '3';
    }
});

bnt4.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '4';
    } else {
        visor.value += '4';
    }
});

bnt5.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '5';
    } else {
        visor.value += '5';
    }
});

bnt6.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '6';
    } else {
        visor.value += '6';
    }
});

bnt7.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '7';
    } else {
        visor.value += '7';
    }
});

bnt8.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '8';
    } else {
        visor.value += '8';
    }
});

bnt9.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '9';
    } else {
        visor.value += '9';
    }
});

bntPonto.addEventListener('click', () => {
    if (visor.value === ultimoResultado) {
        visor.value = '.';
    } else {
        visor.value += '.';
    }
});

bntDividir.addEventListener('click', () => {
    if (!verificaUltimoCaracter())
        visor.value += '/';
});

bntSubtrair.addEventListener('click', () => {
    if (!verificaUltimoCaracter())
        visor.value += '-';
});

bntSomar.addEventListener('click', () => {
    if (!verificaUltimoCaracter())
        visor.value += '+';
});

bntMultiplicar.addEventListener('click', () => {
    if (!verificaUltimoCaracter())
        visor.value += '*';
});

bntLimpar.addEventListener('click', () => {
    visor.value = '';
});

let expressoes='';
const igual = " = ";
let ultimoResultado;
bntResultado.addEventListener('click', () => {
    if (!verificaUltimoCaracter()) {
        try {
            expressoes += visor.value; 
            visor.value = eval(visor.value);
            ultimoResultado = visor.value;
            expressoes += ' = ' + ultimoResultado + '\n';
            console.log(expressoes);
        } catch (error) {
            visor.value = 'Erro!';
            alert(`${error.message}`);
        }
    }

});



