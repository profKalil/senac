import React, { useEffect } from 'react';
import './App.css'; 
import Titulo from './lista'; 
import Entrada from './listaInputs';
import Tabela from './listaTabela';
import { scriptPagina } from './script';

function App() {
  useEffect(()=>{
    scriptPagina();
  }, []);
  return (
    <div>
      <Titulo />
      <Entrada />
      <Tabela />
    </div>
  );
}

export default App;
