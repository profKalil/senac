import './lista.css';

const tabela = () => {
    return (
        <div>
            <table id="tabelaTarefas">
                <thead>
                    <tr>
                        <th>Tarefa</th>
                    </tr>
                </thead>
                <tbody id="corpoTabela">
                    {/* As tarefas serão adicionadas aqui */}
                </tbody>
            </table>
        </div>
    )
};

export default tabela;