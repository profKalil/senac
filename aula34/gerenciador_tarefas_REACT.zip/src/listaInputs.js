import './lista.css';

const inputTarefa = () => {
    return (
        <div>
            <input type="text" id="tarefa" placeholder="Digite uma tarefa" /><button id="adicionarBtn">Adicionar</button>
            <button id="salvarBtn">Salvar</button>
            <button id="carregarBtn">Carregar Tarefas</button>

            { /** Objeto em Javascript
            const carro = {
                cor: 'azul',                        <- atributos
                modelo: 'kombi',
                ano: 1975,
                ligar: function() {                 <- método
                console.log('O carro está ligado.');
                }
            };
            */ }

            <input type="file" id="fileInput" style={{ display:'none'}}></input>
        </div>
    )
};

export default inputTarefa;