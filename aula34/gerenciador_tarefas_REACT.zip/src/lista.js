import './lista.css';

const tituloApp = () => {
    return <h1>Lista de Tarefas</h1>;
};

export default tituloApp;