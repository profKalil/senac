import './App.css';
import Inicio from './componentes/Inicio';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/inicio" element={<Inicio />} />
      </Routes>
    </Router>
  )
}

function Home() {

  return (
    <>
      <div>
      </div>
      <h1>Quiz</h1>
      <div className="card">
        <button >
          <Link to="/inicio">INICIAR</Link>
        </button>
      </div>
      <p className="read-the-docs">
        Clique no botão para iniciar o Quiz
      </p>
    </>
  )
}

export default App
