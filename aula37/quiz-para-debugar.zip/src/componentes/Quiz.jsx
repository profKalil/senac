import React, { useState } from 'react'
import perguntas from './Perguntas';

function Opcoes(props) {
    const opcoes = props.opcoes;
    const aoEscolher = props.aoEscolher;

    return (
        <div>
            <button onClick={function () { aoEscolher('A') }} >
                A: {opcoes.A}
            </button>
            <button onClick={function () { aoEscolher('B') }} >
                B: {opcoes.B}
            </button>
            <button onClick={function () { aoEscolher('C') }} >
                C: {opcoes.C}
            </button>
        </div>
    )
}

function Quiz({ proximaFase, reiniciarFase }) {
    const [indicePergunta, setIndicePergunta] = useState(0); // Guarda a pergunta atual
    const [respostasUsuario, setRespostasUsuario] = useState([]); // Guarda as respostas do usuário
    const [pontuacao, setPontuacao] = useState(0); // Guarda a pontuação
  
    const lidarComResposta = (resposta) => {
      const acertou = resposta === perguntas[indicePergunta].correta;
      
      setRespostasUsuario([...respostasUsuario, acertou]);
  
      if (acertou) {
        setPontuacao(pontuacao + 1);
      }
  
      const proximaPergunta = indicePergunta + 1;
      if (proximaPergunta < perguntas.length) {
        setIndicePergunta(proximaPergunta);
      } else {
        // Fim do quiz, verificar se acertou todas
        if (respostasUsuario.filter(r => r).length + (acertou ? 1 : 0) === perguntas.length) {
          proximaFase();
        } else {
          reiniciarFase();
        }
      }
    };
  
    return (
      <div>
        <h2>{perguntas[indicePergunta].textoPergunta}</h2>
        <Opcoes opcoes={perguntas[indicePergunta].opcoes} aoEscolher={lidarComResposta} />
      </div>
    );
  }
  
  export default Quiz;
  