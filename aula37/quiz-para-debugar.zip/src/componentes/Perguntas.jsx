import React from 'react'

const perguntas = [
    {
        textoPergunta: 'Pergunta1', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta2', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta3', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta4', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta5', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    }
]

export default perguntas;