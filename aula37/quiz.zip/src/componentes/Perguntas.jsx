import React, { useState } from 'react';

// Lista de perguntas
const perguntas = [
  { textoPergunta: 'Qual é a cor do céu?', opcoes: { A: 'Azul', B: 'Verde', C: 'Vermelho' }, correta: 'A' },
  { textoPergunta: 'Quantos dias tem uma semana?', opcoes: { A: '5', B: '7', C: '10' }, correta: 'B' },
  { textoPergunta: 'Qual é o maior planeta do sistema solar?', opcoes: { A: 'Marte', B: 'Terra', C: 'Júpiter' }, correta: 'C' },
  { textoPergunta: 'Quantos minutos tem uma hora?', opcoes: { A: '60', B: '100', C: '90' }, correta: 'A' },
  { textoPergunta: 'Qual é o metal precioso mais conhecido?', opcoes: { A: 'Ouro', B: 'Prata', C: 'Cobre' }, correta: 'A' },
];

// Componente que mostra as opções de resposta
function Opcoes({ opcoes, aoEscolher }) {
  return (
    <div>
      {Object.entries(opcoes).map(([letra, texto]) => (
        <button key={letra} onClick={() => aoEscolher(letra)}>
          {letra}: {texto}
        </button>
      ))}
    </div>
  );
}

// Componente principal
function Quiz({ proximaFase, reiniciarFase }) {
  const [indicePergunta, setIndicePergunta] = useState(0); // Guarda a pergunta atual
  const [respostasUsuario, setRespostasUsuario] = useState([]); // Guarda as respostas do usuário
  const [pontuacao, setPontuacao] = useState(0); // Guarda a pontuação

  const lidarComResposta = (resposta) => {
    const acertou = resposta === perguntas[indicePergunta].correta;
    
    setRespostasUsuario([...respostasUsuario, acertou]);

    if (acertou) {
      setPontuacao(pontuacao + 1);
    }

    const proximaPergunta = indicePergunta + 1;
    if (proximaPergunta < perguntas.length) {
      setIndicePergunta(proximaPergunta);
    } else {
      // Fim do quiz, verificar se acertou todas
      if (respostasUsuario.filter(r => r).length + (acertou ? 1 : 0) === perguntas.length) {
        proximaFase();
      } else {
        reiniciarFase();
      }
    }
  };

  return (
    <div>
      <h2>{perguntas[indicePergunta].textoPergunta}</h2>
      <Opcoes opcoes={perguntas[indicePergunta].opcoes} aoEscolher={lidarComResposta} />
    </div>
  );
}

export default Quiz;
