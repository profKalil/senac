import React, { useState } from 'react';
import Quiz from './Perguntas';

function Inicio() {
  const [faseCompleta, setFaseCompleta] = useState(false); // Estado para controlar se a fase foi concluída
  const [mensagem, setMensagem] = useState("Vamos ver o quanto você sabe!"); // Mensagem de incentivo

  // Função chamada quando o usuário passa de fase
  const proximaFase = () => {
    setFaseCompleta(true); // Marca a fase como completa
    setMensagem("Parabéns! Você respondeu todas as perguntas corretamente!");
  };

  // Função chamada para reiniciar o quiz
  const reiniciarFase = () => {
    setFaseCompleta(false); // Reseta o estado para reiniciar o quiz
    setMensagem("Tente novamente! Você consegue!");
  };

  // Função que reinicia o quiz do zero (como se fosse o F5)
  const reiniciarQuiz = () => {
    setFaseCompleta(false); // Reinicia a fase
    setMensagem("Vamos ver o quanto você sabe!"); // Reinicia a mensagem
  };

  return (
    <div>
      {faseCompleta ? (
        <>
          <h2>{mensagem}</h2> {/* Exibe a mensagem de fase completa */}
          <button onClick={reiniciarQuiz}>Reiniciar Quiz</button> {/* Botão para reiniciar o quiz */}
        </>
      ) : (
        <>
          <h2>{mensagem}</h2> {/* Exibe a mensagem durante o quiz */}
          <Quiz proximaFase={proximaFase} reiniciarFase={reiniciarFase} />
          <button onClick={reiniciarQuiz}>Reiniciar Quiz</button> {/* Botão para reiniciar o quiz durante o jogo */}
        </>
      )}
    </div>
  );
}

export default Inicio;
