import React, { useState, useEffect } from 'react'
import Opcoes from './Opcoes';

function Quiz({ proximaFase, reiniciarFase }) {
    const [indicePergunta, setIndicePergunta] = useState(0); // Guarda a pergunta atual
    const [respostasUsuario, setRespostasUsuario] = useState([]); // Guarda as respostas do usuário
    const [pontuacao, setPontuacao] = useState(0); // Guarda a pontuação
  
    useEffect(() => {
      fetch('http://localhost:5000/perguntas')
        .then((res) => res.json())
        .then((data) => {
          setPerguntas(data);
        })
        .catch((error) => {
          console.error("Erro ao buscar perguntas:", error);
        });
    }, []);
  

    const lidarComResposta = (resposta) => {
      const acertou = resposta === perguntas[indicePergunta].correta;
      
      setRespostasUsuario([...respostasUsuario, acertou]);
  
      if (acertou) {
        setPontuacao(pontuacao + 1);
      }
  
      const proximaPergunta = indicePergunta + 1;
      if (proximaPergunta < perguntas.length) {
        setIndicePergunta(proximaPergunta);
      } else {
        // Fim do quiz, verificar se acertou todas
        if (respostasUsuario.filter(r => r).length + (acertou ? 1 : 0) === perguntas.length) {
          proximaFase();
        } else {
          setPontuacao (0);
          setIndicePergunta(0);
          setRespostasUsuario([]);
          reiniciarFase();
        }
      }
    };
  
    return (
      <div>
        <h3>{perguntas[indicePergunta].textoPergunta}</h3>
        <Opcoes opcoes={perguntas[indicePergunta].opcoes} aoEscolher={lidarComResposta} />
      </div>
    );
  }
  
  export default Quiz;
  