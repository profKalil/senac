import React from 'react'

const perguntas = [
    {
        textoPergunta: 'Pergunta numero 1', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta numero 2', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta numero 3', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta numero 4', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    },
    {
        textoPergunta: 'Pergunta numero 5', opcoes: {
            A: 'opcaoA', B: 'opcaoB', C: 'opcaoC'
        }, correta: 'A'
    }
]

export default perguntas;