import React from 'react'

function Opcoes(props) {
    const opcoes = props.opcoes;
    const aoEscolher = props.aoEscolher;

    return (
        <div>
            <button onClick={function () { aoEscolher('A') }} style={{marginRight:'10px'}} >
                A: {opcoes.A}
            </button>
            <button onClick={function () { aoEscolher('B') }} style={{marginRight:'10px'}} >
                B: {opcoes.B}
            </button>
            <button onClick={function () { aoEscolher('C') }} style={{marginRight:'10px'}} >
                C: {opcoes.C}
            </button>
        </div>
    )
}

export default Opcoes;