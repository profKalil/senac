/* A função DOMContentLoaded garante o JS 
somente após carregar o HTML  */
document.addEventListener('DOMContentLoaded', () => {

    /* Select de idade com FOR (18 a 65 anos) */
    const select = document.getElementById('idade');
    let option = "";
    for (let idade = 18; idade <= 65; idade++) {
        option = document.createElement('option');
        option.value = idade;
        option.textContent = idade;
        select.appendChild(option);
    }

    /* Sections com DIVs do Forms e botões */
    const arraySection = document.querySelectorAll('form > div');
    const btnProximo = document.getElementById('btn-proximo');
    const btnEnviar = document.getElementById('btn-enviar');
    const ancora = document.getElementById('ancora');

    /* Ocultar todas as section do Form com ForEach */
    arraySection.forEach((arraySection, i) => {
        arraySection.style.display = 'none';
    });

    /* Função para mostrar Sections e Botões 
    para ser chamada quando a página for carregada */
    function mostrarSection(indice) {
        arraySection[indice].style.display = 'block';
         
        /* Lógica para exibir botões */
        if (indice===arraySection.length-1) {
            btnProximo.style.display = 'none';
            btnEnviar.style.display = 'inline-block';
        } else {
            btnProximo.style.display = 'inline-block';
            btnEnviar.style.display = 'none';
        }

        /* Lógica para atualizar o href 
        da âncora do botão*/
        const sectionId = `section${indice}`;
        ancora.href = `#${sectionId}`;
        ancora.click();
        /*window.location.hash = sectionId;*/
    }

    /* Passagem de eventos para os botões "Próximo" e "Enviar" */
    let contador = 0;
    btnProximo.addEventListener('click', ()=> {
        if (contador < arraySection.length -1) {
            contador++;
            mostrarSection(contador);
        }
    });
    
    btnEnviar.addEventListener('click', ()=> {
        alert ('Formulário enviado!');
    });


    /* ESPAÇO PARA VALIDAÇÃO DO FORMULÁRIO 
    
    
    
    
    */
    
    mostrarSection(contador);
    

    /** Pop-up com os termos de uso */
    const termosLink = document.querySelector('.termos-link');
    const popup = document.getElementById('termos-popup');
    const fecharPopup = document.querySelector('.fechar-popup');

    termosLink.addEventListener('click', () => {
        popup.style.display = 'flex';

    });

    fecharPopup.addEventListener('click', () => {        
        popup.style.display = 'none';
    });

});



