/** Select de idade com FOR (18 a 65 anos) */

document.addEventListener('DOMContentLoaded', () => {
    const select = document.getElementById('idade');
    let option = "";
    for (let idade = 18; idade <= 65; idade++) {
        option = document.createElement('option');
        option.value = idade;
        option.textContent = idade;
        select.appendChild(option);
    }


    /** Torna uma seção invisível */
    let contador = 0;
    const arraySection = document.querySelectorAll('form > div');
    const btnAnterior = document.getElementById('btn-anterior');
    const btnProximo = document.getElementById('btn-proximo');

    function mostrarSecao(indice) {
        arraySection.forEach((arraySection, i) =>{
            arraySection.style.display = i === indice ? 'block' : 'none';
        });
        btnAnterior.style.display = indice === 0 ? 'none' : 'inline-block';
        btnProximo.style.display = indice === arraySection.length -1 ? 'none' : 'inline-block';
    }
    
    btnProximo.addEventListener('click', ()=> {
        if (contador < arraySection.length -1) {
            contador++;
            mostrarSecao(contador);
        }
    });
    
    btnAnterior.addEventListener('click', ()=> {
        if (contador > 0) {
            contador--;
            mostrarSecao(contador);
        }
    });

    mostrarSecao(contador);


    /** Pop-up com os termos de uso */
    const termosLink = document.querySelector('.termos-link');
    const popup = document.getElementById('termos-popup');
    const fecharPopup = document.querySelector('.fechar-popup');

    termosLink.addEventListener('click', () => {
        popup.style.display = 'flex';

    });

    fecharPopup.addEventListener('click', () => {
        popup.style.display = 'none';
    });

});



