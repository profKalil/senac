import React from 'react'

function Inicio() {
  return (
    <div>Inicio</div>
  )
}

export default Inicio