package senac.baratinha;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;

public class Baratinha extends JFrame {

	private JButton[] btnBaratinha;
	private ImageIcon baratinhaFalse = new ImageIcon(
			"C:\\Users\\Windows\\Desktop\\programas_java\\baratinha\\src\\img\\baratinhaNULL.jpg");;
	private ImageIcon baratinhaTrue = new ImageIcon(
			"C:\\Users\\Windows\\Desktop\\programas_java\\baratinha\\src\\img\\barata.jpg");;

	public Baratinha() {
		inicio();
	}

	private void inicio() {
		setTitle("Minha Janela");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(true);
		tabuleiro();
		JOptionPane.showMessageDialog(this, "Procure e mate a baratinha!");

	}

	private void tabuleiro() {
		btnBaratinha = new JButton[16];
		int largura = 184;
		int altura = 134;
		int margem = 5;
		int x = 5, y = 5;
		Random r = new Random();
		ImageIcon baratinhaIcon;
		int posicao = r.nextInt(15);; 
		for (int i = 0; i < btnBaratinha.length; i++) {			
			if (posicao == i) {
				baratinhaIcon = baratinhaTrue;
			} else {
				baratinhaIcon = baratinhaFalse;
			}
			JButton btn = new JButton(baratinhaIcon);
			btn.setBounds(x, y, largura, altura);
			btn.setBorder(null);
			btn.setOpaque(false);
			btn.setContentAreaFilled(true);
			btn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					if (btn.getIcon()==baratinhaTrue) {
						reiniciar();
					}
				}
			});
			btnBaratinha[i] = btn;
			x += largura + margem;
			if ((i + 1) % 4 == 0) {
				x = margem;
				y += altura + margem;
			}
			add(btnBaratinha[i]);
		}
	}
	
	private void reiniciar() {
	    for (JButton btn : btnBaratinha) {
	        remove(btn);
	    }
	    tabuleiro();
	}

}
