package metas.modelo;

public class ProgressoModelo {
	private int id; 	
	private int id_meta;	
	private double valor;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_meta() {
		return id_meta;
	}

	public void setId_meta(int id_meta) {
		this.id_meta = id_meta;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public ProgressoModelo(int id, int id_meta, double valor) {
		super();
		this.id = id;
		this.id_meta = id_meta;
		this.valor = valor;
	}

}
