package metas.teste;

import metas.controle.UsuarioControle;

// site railway.app para o banco de dados

public class Teste {

	public static void main(String[] args) {
		 
		UsuarioControle usuario = new UsuarioControle();
		//id, nome, senha, email
//		usuario.incluirUsuario(001, "João", "1234", "joao@email.com");
//		usuario.incluirUsuario(002, "João", "1234", "joao@email.com");
//		usuario.incluirUsuario(003, "João", "1234", "joao@email.com");
//		usuario.incluirUsuario(004, "João", "1234", "joao@email.com");		
		usuario.incluirUsuario(005, "Maria", "1234", "joao@email.com");
		usuario.incluirUsuario(006, "Maria", "1234", "joao@email.com");
		usuario.incluirUsuario(007, "Maria", "1234", "joao@email.com");
	}

}
