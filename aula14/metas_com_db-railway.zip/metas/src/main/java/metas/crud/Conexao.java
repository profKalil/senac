package metas.crud;

import java.sql.*;

public class Conexao {
	
	private Connection conexao;
	private final String URL = "jdbc: copie a url do banco de dados railway";
	private final String USUARIO = "root";
	private final String SENHA = " copie a senha do banco de dados railway";
	
	public void conectar() throws SQLException {
		conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
	}
	
	public void fecharConexao() throws SQLException {
		conexao.close();
	}

	public Connection getConexao() {
		return conexao;
	}

	public void setConexao(Connection conexao) {
		this.conexao = conexao;
	}
	
}
