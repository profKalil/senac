package teste;

import java.sql.SQLException;

import modelo.Usuario;

public class Teste {
	
	private static Usuario u = new Usuario();

	public static void main(String[] args) throws SQLException {
	//	incluir();
		consultar();
	}

	private static void consultar() throws SQLException {
		u.consultarUsuario();
		
	}

	private static void incluir() throws SQLException {
		u.incluirUsuario("João da Silva", "senha123");	
	}

}
