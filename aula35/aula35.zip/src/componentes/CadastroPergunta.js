import React from 'react'

function CadastroPergunta() {
    return (
        <div>
            <p>Cadastrar uma pergunta</p>
        </div>
    )
}

export default CadastroPergunta
