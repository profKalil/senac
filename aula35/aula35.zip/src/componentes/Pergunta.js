import React from 'react'

function Pergunta() {
    return (
        <div id="quiz-container">
            <h1>Quiz Interativo</h1>
            <input type="text" id="perguntaInput" readonly />
            <br />
            <button class="btn" id="btnSim">Sim</button>
            <button class="btn" id="btnNao">Não</button> 
        </div>
    )
}

export default Pergunta
