import { useState } from 'react';
import './App.css';
import CadastroPergunta from './componentes/CadastroPergunta';
import Pergunta from './componentes/Pergunta';

function App() {
  const [componenteAtivo, setComponenteAtivo] = useState('cadastro');

  const renderizarComponente = () => {
    switch (componenteAtivo) {
      case 'pergunta':
        return <Pergunta />

      default:
        return <CadastroPergunta />
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <nav>
          <button onClick={()=> setComponenteAtivo('pergunta') }>Responder Pergunta</button>
        <button onClick={()=> setComponenteAtivo('cadastrar') }>Cadastrar Pergunta</button>
        </nav>        
        {renderizarComponente()}
      </header>
    </div>
  );
}

export default App;
