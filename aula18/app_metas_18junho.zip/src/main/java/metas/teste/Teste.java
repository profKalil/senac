package metas.teste;

import java.sql.SQLException;

//import metas.crud.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import metas.jpa.Usuario;

public class Teste {

	public static void main(String[] args) throws SQLException {
//		Inclusao i = new Inclusao();
//
//		//i.incluirUsuario("010.010.010-00", "Joao", "1234", "joao@email.com");
//		//i.incluirUsuario("110.010.010-00", "Maria", "1234", "maria@email.com");
//		// i.incluirMeta("Consórcio", 1000.00, 0.00, "010.010.010-00");		
//		// i.incluirProgresso(90.00, 5);
//		
//		//i.incluirUsuario("210.010.010-00", "Jose", "1234", "jose@email.com");
//		
//		Exclusao e = new Exclusao();
//		//e.excluirUsuario("010.010.010-00");
//		
//		Alteracao a = new Alteracao();
//		//a.alterarUsuario("010.010.010-00", "João das Couves", "joaodascouves@email.com");
//		
//		
//		Consulta c = new Consulta();
//		c.consultarTodos();

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("metasPU");
		EntityManager entityManager = entityManagerFactory.createEntityManager();

		 
		entityManager.getTransaction().begin();
		 
		Usuario usuario = new Usuario();
		usuario.setCpf("12345678900");
		usuario.setNome("João da Silva");
		usuario.setSenha("senha123");
		usuario.setEmail("joao.silva@email.com");

		 
		entityManager.persist(usuario);
		entityManager.getTransaction().commit();

		 
		entityManager.close();
		entityManagerFactory.close();

		System.out.println("Usuário criado com sucesso!");

	}
}
