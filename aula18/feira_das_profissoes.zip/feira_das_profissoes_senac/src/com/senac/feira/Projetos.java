// github.com/profkalil
// www.jovemprogramador.com.br

package com.senac.feira;

import java.util.Scanner;
import javax.swing.*;

public class Projetos {

	public static void main(String args[]) {
		// imprimeOla();
		// somarDoisNumerosNoConsole();
		// somarDoisNumerosComPopUp();
		calculadoraComFrame();
	}

	private static void calculadoraComFrame() {
		JFrame tela = new JFrame(":: DIGITE DOIS NÚMEROS :: ");
		tela.setSize(650, 620);
		tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tela.setLocationRelativeTo(null);
		tela.setLayout(null);
		tela.setResizable(false);

		// Entrada
		JTextField txtNum1 = new JTextField();
		txtNum1.setBounds(100, 40, 400, 30);
		tela.add(txtNum1);
		JTextField txtNum2 = new JTextField();
		txtNum2.setBounds(100, 100, 400, 30);
		tela.add(txtNum2);
		JLabel lblResultado = new JLabel(" RESULTADO  >>  ");
		lblResultado.setBounds(100, 160, 400, 30);
		tela.add(lblResultado);

		// Processo
		JButton btnSomar = new JButton(" Somar |  +  | ");
		btnSomar.setBounds(100, 220, 400, 30);
		btnSomar.addActionListener(somar -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = num1 + num2;

			// Saída
			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f", num1));
		});

		JButton btnSubtrair = new JButton(" Subtrair |  -  | ");
		btnSubtrair.setBounds(100, 280, 400, 30);
		btnSubtrair.addActionListener(subtrair -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = num1 - num2;

			// Saída
			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f", num1));
		});

		JButton btnMultiplicar = new JButton(" Multiplicar |  *  | ");
		btnMultiplicar.setBounds(100, 340, 400, 30);
		btnMultiplicar.addActionListener(multiplicar -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = num1 * num2;

			// Saída
			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f", num1));
		});

		JButton btnDividir = new JButton(" Dividir |  /  |");
		btnDividir.setBounds(100, 400, 400, 30);
		btnDividir.addActionListener(dividir -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = num1 / num2;

			// Saída
			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f", num1));
		});

		JButton btnPotencia = new JButton(" Potencia |  **  |");
		btnPotencia.setBounds(100, 460, 400, 30);
		btnPotencia.addActionListener(dividir -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = Math.pow(num1, num2);

			// Saída
			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f", num1));
		});

		JButton btnRaiz = new JButton(" Raiz Quadrada ");
		btnRaiz.setBounds(100, 520, 400, 30);
		btnRaiz.addActionListener(dividir -> {
			double num1 = Double.parseDouble(txtNum1.getText());
			double num2 = Double.parseDouble(txtNum2.getText());
			num1 = Math.sqrt(num1);
			num2 = Math.sqrt(num2);

			lblResultado.setText(" RESULTADO  >>  " + String.format("%.2f  |   %.2f", num1, num2));
		});

		tela.add(btnSomar);
		tela.add(btnSubtrair);
		tela.add(btnMultiplicar);
		tela.add(btnDividir);
		tela.add(btnPotencia);
		tela.add(btnRaiz);
		tela.setVisible(true);
	}

	private static void somarDoisNumerosComPopUp() {

		double num1 = Double.parseDouble(JOptionPane.showInputDialog(null));
		double num2 = Double.parseDouble(JOptionPane.showInputDialog(null));
		num1 = num1 + num2;
		JOptionPane.showMessageDialog(null, "O resultado da soma é >> " + num1);

	}

	private static void somarDoisNumerosNoConsole() {
		Scanner sc = new Scanner(System.in);
		System.out.print("Primeiro número : ");
		double num1 = sc.nextDouble();
		System.out.print("Segundo número : ");
		double num2 = sc.nextDouble();
		System.out.printf("A soma de %.2f e %.2f é %.2f ", num1, num2, (num1 + num2));
		sc.close();
	}

	private static void imprimeOla() {
		JOptionPane.showMessageDialog(null, "Olá Mundo SENAC!!");
	}

}
