package metas.teste;

import java.sql.SQLException;

import metas.crud.Inclusao;

public class Teste {

	public static void main(String[] args) throws SQLException {
		Inclusao in = new Inclusao();

		in.incluirUsuario("010.010.010-00", "Joao", "1234", "joao@email.com");
		in.incluirMeta("Poupança", 100000.00, 0.00, "010.010.010-00");		
		in.incluirProgresso(25.00, 1);

	}
}
