/* Eventos em geral
    Exemplos de eventos: (1) mouse, (2) teclado, (3) formulário, (4) janela, (5) toque, (6) arrastar/soltar, (7) foco

Ex.: Clicar na bola para ela se mover... 
***********************************************/

/*let posicaoX = 0;
const bola = document.getElementById('bola'); 

function moverBolaMouse(event) {
    posicaoX += 30;
    bola.style.left = posicaoX + 'px';         // manipula o CSS inline (dentro da DIV)
};
document.getElementById('bola').addEventListener('click', moverBolaMouse);
*/


/* Controle de fluxo: if else
 
Ex.: Vamos usar o teclado para mover a bola em toda as direções!  
*******************************************************************/

let posicaoX = 0;  // posição da bola no eixo x
let posicaoY = 0;  // posição da bola no eixo y
const bola = document.getElementById('bola');    // guarda a DIV na variável bola

function moverBolaTeclado(event) {
    if (event.key === 'ArrowRight') {
        posicaoX += 30;  // incremento
    } else if (event.key === 'ArrowLeft') {
        posicaoX -= 30;  // decremento
    } else if (event.key === 'ArrowDown') {
        posicaoY += 30;  
    } else if (event.key === 'ArrowUp') {
        posicaoY -= 30;
    }
    bola.style.left = posicaoX + 'px';
    bola.style.top = posicaoY + 'px';
};
document.addEventListener('keydown', moverBolaTeclado);


/* Estrutura de repetição: while

Ex.: Vamos contar até 7 com um click
************************************/

function inserirValor() {
    let num = 1;
    let h2 = document.getElementById('titulo');
    let ul = document.getElementById('lista');
    let li;
    
    h2.appendChild(document.createTextNode('Números de 1 a 7: '));
    
    while (num <= 7) {
        li = document.createElement('li');
        li.appendChild(document.createTextNode(num));
        ul.appendChild(li);
        num += 1;
    }

    // Remove o event listener após a primeira execução
    document.removeEventListener('click', inserirValor);
}

document.addEventListener('click', inserirValor);







