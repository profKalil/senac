package modelo;

import java.sql.*;

public class Usuario {

	private PreparedStatement declaracao;
	private ResultSet resultado;

	// C do CRUD
	public void incluirUsuario(String nome, String senha) throws SQLException {

		try {
			declaracao = Conexao.getConexao().prepareStatement("INSERT INTO tb_usuario (nome, senha) VALUES (?,?)");
			declaracao.setString(1, nome);
			declaracao.setString(2, senha);
			declaracao.executeUpdate();
			System.out.println("\nUsuário adicionado com sucesso");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}

	// R do CRUD
	public void consultarUsuario() throws SQLException {

		try {
			declaracao = Conexao.getConexao().prepareStatement("SELECT * FROM tb_usuario");
			resultado = declaracao.executeQuery();
			System.out.println("\n\n:: LISTA DE USUARIOS ::");
			while (resultado.next()) {
				System.out.println("\n  Id: " + resultado.getInt("id"));
				System.out.println("  Nome: " + resultado.getString("nome"));
				System.out.println("  Senha: " + resultado.getString("senha"));

			}
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}

	// U do CRUD
	public void atualizarUsuario(int id, String nome, String senha) throws SQLException {

		boolean virgula = false;
		int contador = 1;
		String sql = "UPDATE tb_usuario SET ";
		// StringBuilder sql = new StringBuilder("UPDATE tb_usuario SET ");

		if (nome != null) {
			sql = sql + "nome = ?";
			// sql.append("nome = ?");
			virgula = true;
		}
		if (senha != null) {
			if (virgula) {
				sql = sql + ", ";
				// sql.append(",");
			}
			sql = sql + "senha = ? ";
			// sql.append("senha = ?");
		}
		sql = sql + "WHERE id = ?";
		// sql.append("WHERE id = ?");

		try {
			declaracao = Conexao.getConexao().prepareStatement(sql);
			// declaracao = Conexao.getConexao().prepareStatement(sql.toString());

			if (nome != null) {
				declaracao.setString(contador++, nome);
			}

			if (senha != null) {
				declaracao.setString(contador++, senha);
			}
			declaracao.setInt(contador, id);
			declaracao.executeUpdate();
			System.out.println("\nAlteração realizada com sucesso!");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}

	// D do CRUD
	public void deletarUsuario(int id) throws SQLException {
		try {
			declaracao = Conexao.getConexao().prepareStatement("DELETE FROM tb_usuario WHERE id=?");
			declaracao.setInt(1, id);
			declaracao.executeUpdate();
			System.out.println("\nUsuário excluído com sucesso!");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}
}
