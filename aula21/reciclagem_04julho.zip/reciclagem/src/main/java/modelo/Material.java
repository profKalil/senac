package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Material {
	private PreparedStatement declaracao;
	private ResultSet resultado;

	// C do CRUD
	public void incluirMaterial(String tipo, double quantidade, double valorKg, double valorTotal, int idUsuario)
			throws SQLException {

		try {
			declaracao = Conexao.getConexao().prepareStatement(
					"INSERT INTO tb_material (tipo, quantidade, valor_kg, valor_total, tb_usuario_id) VALUES (?,?,?,?,?)");
			declaracao.setString(1, tipo);
			declaracao.setDouble(2, quantidade);
			declaracao.setDouble(3, valorKg);
			valorTotal = quantidade * valorKg;
			declaracao.setDouble(4, valorTotal);
			declaracao.setInt(5, idUsuario);
			declaracao.executeUpdate();
			System.out.println("\nMaterial adicionado com sucesso");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}

	// R do CRUD
	public void consultarMaterial() throws SQLException {

		try {
			declaracao = Conexao.getConexao().prepareStatement("SELECT * FROM tb_material");
			resultado = declaracao.executeQuery();
			System.out.println("\n\n:: RELAÇÃO DE MATERIAIS ::");
			while (resultado.next()) {
				System.out.println("\n  Id: " + resultado.getInt("id"));
				System.out.println("  Tipo: " + resultado.getString("tipo"));
				System.out.println("  Qtdade: " + resultado.getDouble("quantidade"));
				System.out.println("  Valor/Kg: " + resultado.getDouble("valor_kg"));
				System.out.println("  Valor Total: " + resultado.getDouble("valor_total"));
				System.out.println("  Id Usuario: " + resultado.getInt("tb_usuario_id"));
			}
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}

	// U do CRUD
	public void atualizarMaterial(int id, Double quantidade, Double valorKg) throws SQLException {
		boolean virgula = false;
		int contador = 1;
		double _quantidade, _valorKg, total = 0;
		String sql = "UPDATE tb_material SET ";
		if (quantidade != null) {
			sql = sql + "quantidade = ?";
			virgula = true;
			try {
				declaracao = Conexao.getConexao().prepareStatement("SELECT valor_kg FROM tb_material WHERE id =?");
				declaracao.setInt(1, id);
				resultado = declaracao.executeQuery();
				_valorKg = Double.parseDouble(resultado.toString());
				total = quantidade * _valorKg;
			} catch (SQLException erro) {
				System.out.println(erro);
			}
		}
		if (valorKg != null) {
			if (virgula) {
				sql = sql + ", ";
			}
			sql = sql + "valor_kg = ? ";
			try {
				declaracao = Conexao.getConexao().prepareStatement("SELECT quantidade FROM tb_material WHERE id =?");
				declaracao.setInt(1, id);
				resultado = declaracao.executeQuery();
				_quantidade = Double.parseDouble(resultado.toString());
				total = _quantidade * valorKg;
			} catch (SQLException err) {
				System.out.println(err);
			}
		}
		if (valorKg != null && quantidade != null) {
			total = valorKg * quantidade;
		}
		sql = sql + ", valor_total = ? WHERE id = ?";

		System.out.println(sql);

		try {
			declaracao = Conexao.getConexao().prepareStatement(sql);
			if (quantidade != null) {
				declaracao.setDouble(contador++, quantidade);
			}
			if (valorKg != null) {
				declaracao.setDouble(contador++, valorKg);
			}
			if (quantidade != null || valorKg != null) {
				declaracao.setDouble(contador++, total);
			} else {
				return;
			}
			declaracao.setInt(contador, id);
			declaracao.executeUpdate();

			System.out.println("\nAlteração realizada com sucesso!");

		} catch (SQLException erro) {
			System.out.println(erro);
		}

	}

	// D do CRUD
	public void deletarMaterial(int id) throws SQLException {

	}
}
