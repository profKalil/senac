package modelo;

import java.sql.*;

public class Usuario {

	private PreparedStatement declaracao;
	private ResultSet resultado;
	
	// C do CRUD
	public void incluirUsuario(String nome, String senha) throws SQLException {
		
		try {
		declaracao = Conexao.getConexao().prepareStatement("INSERT INTO tb_usuario (nome, senha) VALUES (?,?)");
		declaracao.setString(1, nome);
		declaracao.setString(2, senha);
		declaracao.executeUpdate();
		System.out.println("\nUsuário adicionado com sucesso");
		} catch (SQLException erro) {
			System.out.println(erro);
		}		 
	}
	
	// R do CRUD
	public void consultarUsuario() throws SQLException {
		 
		try {
			declaracao = Conexao.getConexao().prepareStatement("SELECT * FROM tb_usuario");
			resultado = declaracao.executeQuery();
			System.out.println("\n\n:: LISTA DE USUARIOS ::");
			while(resultado.next()) {
				System.out.println("\n  Id: " + resultado.getInt("id"));
				System.out.println("  Nome: " + resultado.getString("nome"));
				System.out.println("  Senha: " + resultado.getString("senha"));
				
			}
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}
	
	// U do CRUD
	public void atualizarUsuario(int id, String nome, String senha) throws SQLException {
		try {
			declaracao = Conexao.getConexao().prepareStatement(
					"UPDATE tb_usuario SET nome = ?, senha = ? WHERE id = ? ");
		declaracao.setString(1, nome);
		declaracao.setString(2, senha);
		declaracao.setInt(3, id);
		declaracao.executeUpdate();
		System.out.println("\nAlteração realizada com sucesso!");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}
	
	public void atualizarUsuario(int id, String nome) throws SQLException {
		try {
			declaracao = Conexao.getConexao().prepareStatement(
					"UPDATE tb_usuario SET nome = ? WHERE id = ? ");
		declaracao.setString(1, nome);
		declaracao.setInt(2, id);
		declaracao.executeUpdate();
		System.out.println("\nAlteração realizada com sucesso!");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}
	
	// D do CRUD
	public void deletarUsuario(int id) throws SQLException {
		try {
			declaracao = Conexao.getConexao().prepareStatement("DELETE FROM tb_usuario WHERE id=?");
			declaracao.setInt(1, id);
			declaracao.executeUpdate();
			System.out.println("\nUsuário excluído com sucesso!");
		} catch (SQLException erro) {
			System.out.println(erro);
		}
	}
}
