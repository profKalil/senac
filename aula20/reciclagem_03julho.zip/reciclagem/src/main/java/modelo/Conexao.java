package modelo;

import java.sql.*;

public class Conexao {
	
	private static Connection conexao;
	private static final String URL = "jdbc:mysql://localhost:3306/dbreciclagem";
	private static final String USUARIO =  "root";
	private static final String SENHA = "Sen@CEdu2024";

	public static Connection getConexao() throws SQLException {
		conexao = DriverManager.getConnection(URL, USUARIO, SENHA);
		return conexao;
	} 
}
