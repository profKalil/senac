package teste;

import java.sql.SQLException;

import modelo.Material;
import modelo.Usuario;

public class Teste {
	
	private static Usuario u = new Usuario();
	private static Material m = new Material();

	public static void main(String[] args) throws SQLException {
		
		consultar();
		//System.out.println("");
		incluir();
		//alterar();
		//excluir();
		consultar();
	}

	private static void excluir() throws SQLException {
		u.deletarUsuario(3);
		
	}

	private static void alterar() throws SQLException {
		u.atualizarUsuario(2, "Maria Couves das Dores");		
	}

	private static void consultar() throws SQLException {
		u.consultarUsuario();
		m.consultarMaterial();
		
	}

	private static void incluir() throws SQLException {
		//u.incluirUsuario("Jose das Dores", "senha123");
		m.incluirMaterial("Vidro", 8, 0.1, (8*0.1), 4);
	}

}
